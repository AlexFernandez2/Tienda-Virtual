-- Insertar datos en la tabla de usuarios
INSERT INTO usuarios (nombre, correo, contrasena) VALUES
    ('Usuario1', 'usuario1@example.com', 'contrasena1'),
    ('Usuario2', 'usuario2@example.com', 'contrasena2'),
    ('Usuario3', 'usuario3@example.com', 'contrasena3'),
    ('Usuario4', 'usuario4@example.com', 'contrasena4'),
    ('Usuario5', 'usuario5@example.com', 'contrasena5'),
    ('Usuario6', 'usuario6@example.com', 'contrasena6');

-- Insertar datos en la tabla de productos
INSERT INTO productos (nombre_producto, descripcion, precio) VALUES
    ('Producto1', 'Descripción del producto 1', 29.99),
    ('Producto2', 'Descripción del producto 2', 39.99),
    ('Producto3', 'Descripción del producto 3', 49.99),
    ('Producto4', 'Descripción del producto 4', 59.99),
    ('Producto5', 'Descripción del producto 5', 69.99),
    ('Producto6', 'Descripción del producto 6', 79.99);

-- Insertar datos en la tabla de clientes
INSERT INTO clientes (nombre_cliente, correo_cliente, telefono_cliente) VALUES
    ('Cliente1', 'cliente1@example.com', '123-456-7890'),
    ('Cliente2', 'cliente2@example.com', '234-567-8901'),
    ('Cliente3', 'cliente3@example.com', '345-678-9012'),
    ('Cliente4', 'cliente4@example.com', '456-789-0123'),
    ('Cliente5', 'cliente5@example.com', '567-890-1234'),
    ('Cliente6', 'cliente6@example.com', '678-901-2345');

-- Insertar datos en la tabla de entrenadores
INSERT INTO entrenadores (nombre_entrenador, correo_entrenador, telefono_entrenador) VALUES
    ('Entrenador1', 'entrenador1@example.com', '789-012-3456'),
    ('Entrenador2', 'entrenador2@example.com', '890-123-4567'),
    ('Entrenador3', 'entrenador3@example.com', '901-234-5678'),
    ('Entrenador4', 'entrenador4@example.com', '012-345-6789'),
    ('Entrenador5', 'entrenador5@example.com', '123-456-7890'),
    ('Entrenador6', 'entrenador6@example.com', '234-567-8901');

-- Insertar datos en la tabla de relación entre entrenadores y clientes
INSERT INTO entrenador_cliente_relacion (id_entrenador, id_cliente) VALUES
    (1, 1),
    (1, 2),
    (2, 3),
    (2, 4),
    (3, 5),
    (3, 6);
