-- Crear la base de datos
CREATE DATABASE IF NOT EXISTS gym_database;
USE gym_database;

-- Tabla de usuarios
CREATE TABLE IF NOT EXISTS usuarios (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(50) NOT NULL,
    correo VARCHAR(50) NOT NULL,
    contrasena VARCHAR(255) NOT NULL
);

-- Tabla de productos
CREATE TABLE IF NOT EXISTS productos (
    id_producto INT PRIMARY KEY AUTO_INCREMENT,
    nombre_producto VARCHAR(50) NOT NULL,
    descripcion TEXT,
    precio DECIMAL(10, 2) NOT NULL
);

-- Tabla de clientes
CREATE TABLE IF NOT EXISTS clientes (
    id_cliente INT PRIMARY KEY AUTO_INCREMENT,
    nombre_cliente VARCHAR(50) NOT NULL,
    correo_cliente VARCHAR(50) NOT NULL,
    telefono_cliente VARCHAR(20),
    FOREIGN KEY (id_cliente) REFERENCES usuarios(id)
);

-- Tabla de entrenadores
CREATE TABLE IF NOT EXISTS entrenadores (
    id_entrenador INT PRIMARY KEY AUTO_INCREMENT,
    nombre_entrenador VARCHAR(50) NOT NULL,
    correo_entrenador VARCHAR(50) NOT NULL,
    telefono_entrenador VARCHAR(20),
    FOREIGN KEY (id_entrenador) REFERENCES usuarios(id)
);

-- Tabla de relación entre entrenadores y clientes
CREATE TABLE IF NOT EXISTS entrenador_cliente_relacion (
    id_relacion INT PRIMARY KEY AUTO_INCREMENT,
    id_entrenador INT,
    id_cliente INT,
    FOREIGN KEY (id_entrenador) REFERENCES entrenadores(id_entrenador),
    FOREIGN KEY (id_cliente) REFERENCES clientes(id_cliente)
);
