<?php
// Configuración de la conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "gym_database";

// Crear la conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Mensaje de error o éxito inicial vacío
$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $usuario = test_input($_POST["username"]);
    $contrasena = test_input($_POST["password"]);

    // Consulta SQL para verificar las credenciales
    $sql = "SELECT id, nombre FROM usuarios WHERE correo = '$usuario' AND contrasena = '$contrasena'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Inicio de sesión exitoso, iniciar la sesión y mostrar mensaje de éxito
        session_start();
        $row = $result->fetch_assoc();
        $_SESSION["id_usuario"] = $row["id"];
        $_SESSION["nombre_usuario"] = $row["nombre"];
        $mensaje = "¡Inicio de sesión exitoso!";
    } else {
        // Credenciales incorrectas, mostrar mensaje de error
        $mensaje = "Credenciales incorrectas. Inténtalo de nuevo.";
    }
}

// Función para limpiar y validar datos
function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>